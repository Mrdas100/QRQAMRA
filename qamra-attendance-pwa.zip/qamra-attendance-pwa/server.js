import express from "express";
import cors from "cors";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import webpush from "web-push";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const envPath = path.join(__dirname, ".env");
if (fs.existsSync(envPath)) {
  const text = fs.readFileSync(envPath, "utf8");
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=(.*)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
  }
}

const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "change-me-now";
const BREAK_LIMIT = Number(process.env.BREAK_LIMIT_MINUTES || 40);
const BREAK_NOTIFY = String(process.env.BREAK_NOTIFY_MINUTES || "30,35,40")
  .split(",").map(Number).filter(Number.isFinite);

const SHOP_LAT = process.env.SHOP_LAT ? Number(process.env.SHOP_LAT) : null;
const SHOP_LON = process.env.SHOP_LON ? Number(process.env.SHOP_LON) : null;
const SHOP_RADIUS = Number(process.env.SHOP_RADIUS_METERS || 120);

const VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY || "";
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY || "";
if (VAPID_PUBLIC && VAPID_PRIVATE) {
  webpush.setVapidDetails(
    process.env.VAPID_SUBJECT || "mailto:owner@example.com",
    VAPID_PUBLIC,
    VAPID_PRIVATE
  );
}

const db = new Database(path.join(__dirname, "data", "qamra.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS employees (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name_ar TEXT NOT NULL,
  name_bn TEXT,
  code TEXT NOT NULL UNIQUE,
  pin_hash TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  device_id TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  employee_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  server_time TEXT NOT NULL,
  lat REAL,
  lon REAL,
  accuracy REAL,
  device_id TEXT,
  FOREIGN KEY(employee_id) REFERENCES employees(id)
);
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  employee_id INTEGER NOT NULL,
  endpoint TEXT NOT NULL UNIQUE,
  subscription_json TEXT NOT NULL,
  FOREIGN KEY(employee_id) REFERENCES employees(id)
);
CREATE TABLE IF NOT EXISTS push_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  employee_id INTEGER NOT NULL,
  break_start_event_id INTEGER NOT NULL,
  minute_mark INTEGER NOT NULL,
  sent_at TEXT NOT NULL,
  UNIQUE(employee_id, break_start_event_id, minute_mark)
);
CREATE TABLE IF NOT EXISTS admin (
  id INTEGER PRIMARY KEY CHECK (id=1),
  username TEXT NOT NULL,
  pin_hash TEXT NOT NULL
);
`);

const existingAdmin = db.prepare("SELECT id FROM admin WHERE id=1").get();
if (!existingAdmin) {
  const u = process.env.ADMIN_USERNAME || "admin";
  const p = process.env.ADMIN_PIN || "2468";
  db.prepare("INSERT INTO admin(id,username,pin_hash) VALUES(1,?,?)")
    .run(u, bcrypt.hashSync(p, 10));
}

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function nowISO() { return new Date().toISOString(); }
function sign(payload) { return jwt.sign(payload, JWT_SECRET, { expiresIn: "30d" }); }

function auth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : "";
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: "unauthorized" }); }
}
function adminOnly(req,res,next){
  if(req.user?.role !== "admin") return res.status(403).json({error:"forbidden"});
  next();
}
function employeeOnly(req,res,next){
  if(req.user?.role !== "employee") return res.status(403).json({error:"forbidden"});
  next();
}

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371000, toRad = d => d * Math.PI / 180;
  const p1 = toRad(lat1), p2 = toRad(lat2);
  const dp = toRad(lat2-lat1), dl = toRad(lon2-lon1);
  const a = Math.sin(dp/2)**2 + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
  return 2*R*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}
function geofenceResult(lat,lon){
  if (SHOP_LAT == null || SHOP_LON == null) return { enabled:false, ok:true, distance:null };
  if (lat == null || lon == null) return { enabled:true, ok:false, distance:null };
  const d = haversine(lat,lon,SHOP_LAT,SHOP_LON);
  return { enabled:true, ok:d <= SHOP_RADIUS, distance:Math.round(d) };
}

function lastEvent(employeeId) {
  return db.prepare("SELECT * FROM events WHERE employee_id=? ORDER BY id DESC LIMIT 1").get(employeeId);
}
function statusFor(employeeId) {
  const last = lastEvent(employeeId);
  if (!last) return { status:"off", last:null, breakStart:null, elapsedBreakMinutes:0 };
  let status = "off";
  if (last.type === "CLOCK_IN" || last.type === "BREAK_END") status = "working";
  if (last.type === "BREAK_START") status = "break";
  if (last.type === "CLOCK_OUT") status = "off";

  let breakStart = null, elapsedBreakMinutes = 0;
  if(status === "break"){
    breakStart = last;
    elapsedBreakMinutes = Math.floor((Date.now() - new Date(last.server_time).getTime())/60000);
  }
  return {status,last,breakStart,elapsedBreakMinutes};
}

app.post("/api/login/employee", (req,res)=>{
  const { code, pin, deviceId } = req.body || {};
  const e = db.prepare("SELECT * FROM employees WHERE code=? AND active=1").get(String(code||"").trim());
  if(!e || !bcrypt.compareSync(String(pin||""), e.pin_hash)) return res.status(401).json({error:"invalid"});
  if(e.device_id && deviceId && e.device_id !== deviceId) return res.status(403).json({error:"device_mismatch"});
  if(!e.device_id && deviceId) db.prepare("UPDATE employees SET device_id=? WHERE id=?").run(deviceId,e.id);
  res.json({
    token: sign({role:"employee",employeeId:e.id}),
    employee:{id:e.id,name_ar:e.name_ar,name_bn:e.name_bn,code:e.code},
    breakLimit: BREAK_LIMIT,
    vapidPublicKey: VAPID_PUBLIC
  });
});

app.post("/api/login/admin",(req,res)=>{
  const {username,pin}=req.body||{};
  const a=db.prepare("SELECT * FROM admin WHERE id=1 AND username=?").get(String(username||""));
  if(!a || !bcrypt.compareSync(String(pin||""),a.pin_hash)) return res.status(401).json({error:"invalid"});
  res.json({token:sign({role:"admin"}),breakLimit:BREAK_LIMIT});
});

app.get("/api/me/status",auth,employeeOnly,(req,res)=>{
  res.json({...statusFor(req.user.employeeId),breakLimit:BREAK_LIMIT,serverTime:nowISO()});
});

app.post("/api/me/action",auth,employeeOnly,(req,res)=>{
  const employeeId=req.user.employeeId;
  const {type,lat,lon,accuracy,deviceId}=req.body||{};
  const allowed=["CLOCK_IN","BREAK_START","BREAK_END","CLOCK_OUT"];
  if(!allowed.includes(type)) return res.status(400).json({error:"bad_action"});

  const e=db.prepare("SELECT * FROM employees WHERE id=? AND active=1").get(employeeId);
  if(!e) return res.status(404).json({error:"employee_not_found"});
  if(e.device_id && deviceId && e.device_id!==deviceId) return res.status(403).json({error:"device_mismatch"});

  const st=statusFor(employeeId);
  const valid =
    (type==="CLOCK_IN" && st.status==="off") ||
    (type==="BREAK_START" && st.status==="working") ||
    (type==="BREAK_END" && st.status==="break") ||
    (type==="CLOCK_OUT" && (st.status==="working" || st.status==="break"));
  if(!valid) return res.status(409).json({error:"invalid_transition",status:st.status});

  // Only require geofence for clock-in and break-end. Break start/out remain recordable.
  const gf=geofenceResult(lat,lon);
  if((type==="CLOCK_IN" || type==="BREAK_END") && gf.enabled && !gf.ok){
    return res.status(403).json({error:"outside_geofence",distance:gf.distance});
  }

  db.prepare(`
    INSERT INTO events(employee_id,type,server_time,lat,lon,accuracy,device_id)
    VALUES(?,?,?,?,?,?,?)
  `).run(employeeId,type,nowISO(),lat??null,lon??null,accuracy??null,deviceId??null);
  res.json({...statusFor(employeeId),geofence:gf,breakLimit:BREAK_LIMIT});
});

app.post("/api/me/push-subscription",auth,employeeOnly,(req,res)=>{
  const sub=req.body?.subscription;
  if(!sub?.endpoint) return res.status(400).json({error:"bad_subscription"});
  db.prepare(`
    INSERT INTO push_subscriptions(employee_id,endpoint,subscription_json)
    VALUES(?,?,?)
    ON CONFLICT(endpoint) DO UPDATE SET employee_id=excluded.employee_id, subscription_json=excluded.subscription_json
  `).run(req.user.employeeId,sub.endpoint,JSON.stringify(sub));
  res.json({ok:true});
});

app.get("/api/admin/employees",auth,adminOnly,(req,res)=>{
  const rows=db.prepare("SELECT id,name_ar,name_bn,code,active,device_id,created_at FROM employees ORDER BY id DESC").all();
  res.json(rows.map(e=>({...e,...statusFor(e.id)})));
});

app.post("/api/admin/employees",auth,adminOnly,(req,res)=>{
  const {name_ar,name_bn,code,pin}=req.body||{};
  if(!name_ar||!code||!pin) return res.status(400).json({error:"missing"});
  try{
    const r=db.prepare("INSERT INTO employees(name_ar,name_bn,code,pin_hash) VALUES(?,?,?,?)")
      .run(name_ar,name_bn||"",String(code).trim(),bcrypt.hashSync(String(pin),10));
    res.json({id:r.lastInsertRowid});
  }catch(e){ res.status(409).json({error:"duplicate_code"}); }
});

app.post("/api/admin/employees/:id/reset-device",auth,adminOnly,(req,res)=>{
  db.prepare("UPDATE employees SET device_id=NULL WHERE id=?").run(Number(req.params.id));
  res.json({ok:true});
});

app.post("/api/admin/employees/:id/toggle",auth,adminOnly,(req,res)=>{
  const e=db.prepare("SELECT active FROM employees WHERE id=?").get(Number(req.params.id));
  if(!e) return res.status(404).json({error:"not_found"});
  db.prepare("UPDATE employees SET active=? WHERE id=?").run(e.active?0:1,Number(req.params.id));
  res.json({ok:true});
});

function monthBounds(month){
  const m = /^\d{4}-\d{2}$/.test(month||"") ? month : new Date().toISOString().slice(0,7);
  const [y,mo]=m.split("-").map(Number);
  const start=new Date(Date.UTC(y,mo-1,1)).toISOString();
  const end=new Date(Date.UTC(y,mo,1)).toISOString();
  return {m,start,end};
}
function reportRows(month){
  const {m,start,end}=monthBounds(month);
  const emps=db.prepare("SELECT id,name_ar,name_bn,code FROM employees ORDER BY name_ar").all();
  const out=[];
  for(const e of emps){
    const ev=db.prepare("SELECT * FROM events WHERE employee_id=? AND server_time>=? AND server_time<? ORDER BY server_time")
      .all(e.id,start,end);
    let workMs=0, breakMs=0, breakOverMs=0, currentWork=null, currentBreak=null, days=new Set();
    for(const x of ev){
      days.add(x.server_time.slice(0,10));
      const t=new Date(x.server_time).getTime();
      if(x.type==="CLOCK_IN"){ currentWork=t; currentBreak=null; }
      if(x.type==="BREAK_START" && currentWork!=null){ workMs += Math.max(0,t-currentWork); currentWork=null; currentBreak=t; }
      if(x.type==="BREAK_END" && currentBreak!=null){
        const dur=Math.max(0,t-currentBreak); breakMs+=dur;
        breakOverMs += Math.max(0,dur-BREAK_LIMIT*60000);
        currentBreak=null; currentWork=t;
      }
      if(x.type==="CLOCK_OUT"){
        if(currentWork!=null) workMs += Math.max(0,t-currentWork);
        if(currentBreak!=null){
          const dur=Math.max(0,t-currentBreak); breakMs+=dur;
          breakOverMs += Math.max(0,dur-BREAK_LIMIT*60000);
        }
        currentWork=null; currentBreak=null;
      }
    }
    out.push({
      month:m,employee_id:e.id,name_ar:e.name_ar,name_bn:e.name_bn,code:e.code,
      attendance_days:days.size,
      work_minutes:Math.round(workMs/60000),
      break_minutes:Math.round(breakMs/60000),
      break_over_minutes:Math.round(breakOverMs/60000),
      events:ev.length
    });
  }
  return out;
}
app.get("/api/admin/report",auth,adminOnly,(req,res)=>res.json(reportRows(req.query.month)));
app.get("/api/admin/report.csv",auth,adminOnly,(req,res)=>{
  const rows=reportRows(req.query.month);
  const esc=v=>`"${String(v??"").replaceAll('"','""')}"`;
  const header=["month","name_ar","name_bn","code","attendance_days","work_minutes","break_minutes","break_over_minutes","events"];
  const csv=[header.join(","),...rows.map(r=>header.map(h=>esc(r[h])).join(","))].join("\n");
  res.setHeader("Content-Type","text/csv; charset=utf-8");
  res.setHeader("Content-Disposition",`attachment; filename="qamra-report-${rows[0]?.month||"month"}.csv"`);
  res.send("\ufeff"+csv);
});

app.get("/api/config",(req,res)=>res.json({breakLimit:BREAK_LIMIT,vapidPublicKey:VAPID_PUBLIC,geofenceEnabled:SHOP_LAT!=null&&SHOP_LON!=null}));

// Push checker: simple for a small shop on an always-on Node/VPS process.
async function checkBreakPushes(){
  if(!VAPID_PUBLIC || !VAPID_PRIVATE) return;
  const employees=db.prepare("SELECT id,name_ar,name_bn FROM employees WHERE active=1").all();
  for(const e of employees){
    const st=statusFor(e.id);
    if(st.status!=="break" || !st.breakStart) continue;
    const mins=Math.floor((Date.now()-new Date(st.breakStart.server_time).getTime())/60000);
    for(const mark of BREAK_NOTIFY){
      if(mins<mark) continue;
      const exists=db.prepare("SELECT 1 FROM push_log WHERE employee_id=? AND break_start_event_id=? AND minute_mark=?")
        .get(e.id,st.breakStart.id,mark);
      if(exists) continue;
      const subs=db.prepare("SELECT * FROM push_subscriptions WHERE employee_id=?").all(e.id);
      const over=Math.max(0,mins-BREAK_LIMIT);
      const body = mins < BREAK_LIMIT
        ? `مضى ${mins} دقيقة من البريك. المتبقي ${Math.max(0,BREAK_LIMIT-mins)} دقيقة.`
        : over===0 ? "انتهى وقت البريك. الرجاء العودة للعمل." : `تجاوزت البريك بـ ${over} دقيقة.`;
      for(const s of subs){
        try{
          await webpush.sendNotification(JSON.parse(s.subscription_json), JSON.stringify({
            title:"شاهي قمرا - البريك",
            body,
            tag:`break-${e.id}-${st.breakStart.id}-${mark}`
          }));
        }catch(err){
          if(err.statusCode===404||err.statusCode===410) db.prepare("DELETE FROM push_subscriptions WHERE id=?").run(s.id);
        }
      }
      db.prepare("INSERT OR IGNORE INTO push_log(employee_id,break_start_event_id,minute_mark,sent_at) VALUES(?,?,?,?)")
        .run(e.id,st.breakStart.id,mark,nowISO());
    }
  }
}
setInterval(checkBreakPushes, 60_000);

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Qamra Attendance running on http://localhost:${PORT}`));
