const CACHE="qamra-v1";
const ASSETS=["/","/index.html","/app.js","/styles.css","/manifest.webmanifest","/icon.svg"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("fetch",e=>{
  if(e.request.method!=="GET") return;
  e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));
});
self.addEventListener("push",e=>{
  let d={title:"شاهي قمرا",body:"تنبيه جديد"};
  try{d=JSON.parse(e.data.text())}catch{}
  e.waitUntil(self.registration.showNotification(d.title||"شاهي قمرا",{
    body:d.body||"",icon:"/icon.svg",badge:"/icon.svg",tag:d.tag||"qamra"
  }));
});
self.addEventListener("notificationclick",e=>{
  e.notification.close();
  e.waitUntil(clients.matchAll({type:"window",includeUncontrolled:true}).then(ws=>{
    if(ws.length) return ws[0].focus();
    return clients.openWindow("/");
  }));
});
