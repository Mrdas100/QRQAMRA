const $=s=>document.querySelector(s);
const T={
 ar:{
  appName:"دوام شاهي قمرا",subtitle:"حضور • بريك • انصراف",employee:"عامل",admin:"مدير",
  employeeCode:"رقم العامل",pin:"الرقم السري",login:"دخول",username:"اسم المستخدم",logout:"خروج من الحساب",
  statusWorking:"على رأس العمل",statusBreak:"في بريك",statusOff:"خارج الدوام",clockIn:"بدء الدوام",
  breakStart:"بدء البريك",breakEnd:"رجعت للعمل",clockOut:"إنهاء الدوام",enableNotifications:"تفعيل تنبيهات البريك",
  dashboard:"لوحة الإدارة",liveStatus:"حالة العمال الآن",working:"على رأس العمل",onBreak:"في بريك",off:"خارج الدوام",
  addEmployee:"إضافة عامل",nameAr:"الاسم بالعربية",nameBn:"الاسم بالبنغالية",save:"حفظ",employees:"العمال",
  refresh:"تحديث",name:"الاسم",status:"الحالة",breakTime:"البريك",actions:"إجراءات",resetDevice:"فك ربط الجهاز",
  disable:"تعطيل",enable:"تفعيل",monthlyReport:"التقرير الشهري",showReport:"عرض التقرير",downloadCsv:"تحميل CSV",
  attendanceDays:"أيام الحضور",workMinutes:"دقائق العمل",breakMinutes:"دقائق البريك",breakOver:"تجاوز البريك",
  events:"الحركات",remaining:"متبقي",elapsed:"مضى",over:"تجاوزت البريك بـ",minutes:"دقيقة",
  locationRequired:"يلزم السماح بالموقع لتسجيل هذه العملية.",outside:"أنت خارج النطاق المسموح للمحل.",
  loginFailed:"بيانات الدخول غير صحيحة.",deviceMismatch:"هذا الحساب مربوط بجهاز آخر. اطلب من المدير فك ربط الجهاز.",
  saved:"تم الحفظ.",notificationsOn:"تم تفعيل التنبيهات.",notificationDenied:"لم يتم السماح بالتنبيهات."
 },
 bn:{
  appName:"কামরা টি হাজিরা",subtitle:"হাজিরা • বিরতি • ছুটি",employee:"কর্মী",admin:"ম্যানেজার",
  employeeCode:"কর্মী নম্বর",pin:"পিন",login:"লগইন",username:"ইউজারনেম",logout:"লগআউট",
  statusWorking:"কাজে আছেন",statusBreak:"বিরতিতে",statusOff:"ডিউটির বাইরে",clockIn:"ডিউটি শুরু",
  breakStart:"বিরতি শুরু",breakEnd:"কাজে ফিরেছি",clockOut:"ডিউটি শেষ",enableNotifications:"বিরতির নোটিফিকেশন চালু করুন",
  dashboard:"ম্যানেজার ড্যাশবোর্ড",liveStatus:"কর্মীদের বর্তমান অবস্থা",working:"কাজে",onBreak:"বিরতিতে",off:"ডিউটির বাইরে",
  addEmployee:"কর্মী যোগ করুন",nameAr:"আরবি নাম",nameBn:"বাংলা নাম",save:"সংরক্ষণ",employees:"কর্মীরা",
  refresh:"রিফ্রেশ",name:"নাম",status:"অবস্থা",breakTime:"বিরতি",actions:"অ্যাকশন",resetDevice:"ডিভাইস আনলিংক",
  disable:"বন্ধ",enable:"চালু",monthlyReport:"মাসিক রিপোর্ট",showReport:"রিপোর্ট দেখুন",downloadCsv:"CSV ডাউনলোড",
  attendanceDays:"হাজিরার দিন",workMinutes:"কাজের মিনিট",breakMinutes:"বিরতির মিনিট",breakOver:"অতিরিক্ত বিরতি",
  events:"ইভেন্ট",remaining:"বাকি",elapsed:"কেটেছে",over:"বিরতি বেশি হয়েছে",minutes:"মিনিট",
  locationRequired:"এই কাজের জন্য লোকেশন অনুমতি প্রয়োজন।",outside:"আপনি দোকানের অনুমোদিত এলাকার বাইরে আছেন।",
  loginFailed:"লগইন তথ্য সঠিক নয়।",deviceMismatch:"এই অ্যাকাউন্ট অন্য ডিভাইসের সাথে যুক্ত। ম্যানেজারকে ডিভাইস রিসেট করতে বলুন।",
  saved:"সংরক্ষিত হয়েছে।",notificationsOn:"নোটিফিকেশন চালু হয়েছে।",notificationDenied:"নোটিফিকেশন অনুমতি দেওয়া হয়নি।"
 }
};
let lang=localStorage.getItem("lang")||"ar";
let empToken=localStorage.getItem("empToken")||"";
let adminToken=localStorage.getItem("adminToken")||"";
let employee=JSON.parse(localStorage.getItem("employee")||"null");
let breakLimit=40, currentStatus=null, ticker=null, vapidPublicKey="";
const deviceId=localStorage.getItem("deviceId")||crypto.randomUUID();
localStorage.setItem("deviceId",deviceId);

function tr(k){return T[lang][k]||T.ar[k]||k}
function applyLang(){
 document.documentElement.lang=lang;
 document.documentElement.dir=lang==="ar"?"rtl":"ltr";
 $("#lang").value=lang;
 document.querySelectorAll("[data-i18n]").forEach(el=>el.textContent=tr(el.dataset.i18n));
 document.querySelectorAll("[data-i18n-placeholder]").forEach(el=>el.placeholder=tr(el.dataset.i18nPlaceholder));
 if(currentStatus) renderEmployee(currentStatus);
}
$("#lang").onchange=e=>{lang=e.target.value;localStorage.setItem("lang",lang);applyLang();renderAdminNames();};
applyLang();

if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js");

function msg(el,text,kind=""){
 el.textContent=text;el.className="notice "+kind;el.classList.remove("hidden");
 setTimeout(()=>el.classList.add("hidden"),5000);
}
async function api(url,opt={},token=""){
 const r=await fetch(url,{...opt,headers:{"Content-Type":"application/json",...(opt.headers||{}),...(token?{Authorization:"Bearer "+token}:{})}});
 const data=await r.json().catch(()=>({}));
 if(!r.ok){const e=new Error(data.error||"error");e.data=data;throw e}
 return data;
}
function show(view){
 ["#loginView","#employeeView","#adminView"].forEach(x=>$(x).classList.add("hidden"));
 $(view).classList.remove("hidden");
}
$("#employeeTab").onclick=()=>{$("#employeeLogin").classList.remove("hidden");$("#adminLogin").classList.add("hidden")};
$("#adminTab").onclick=()=>{$("#adminLogin").classList.remove("hidden");$("#employeeLogin").classList.add("hidden")};

$("#employeeLoginBtn").onclick=async()=>{
 try{
  const d=await api("/api/login/employee",{method:"POST",body:JSON.stringify({code:$("#empCode").value,pin:$("#empPin").value,deviceId})});
  empToken=d.token;employee=d.employee;breakLimit=d.breakLimit||40;vapidPublicKey=d.vapidPublicKey||"";
  localStorage.setItem("empToken",empToken);localStorage.setItem("employee",JSON.stringify(employee));
  show("#employeeView"); await refreshEmployee();
 }catch(e){msg($("#loginMsg"),e.message==="device_mismatch"?tr("deviceMismatch"):tr("loginFailed"),"error")}
};
$("#adminLoginBtn").onclick=async()=>{
 try{
  const d=await api("/api/login/admin",{method:"POST",body:JSON.stringify({username:$("#adminUser").value,pin:$("#adminPin").value})});
  adminToken=d.token;breakLimit=d.breakLimit||40;localStorage.setItem("adminToken",adminToken);
  show("#adminView"); await refreshAdmin();
 }catch{msg($("#loginMsg"),tr("loginFailed"),"error")}
};
$("#logoutEmp").onclick=()=>{empToken="";employee=null;localStorage.removeItem("empToken");localStorage.removeItem("employee");clearInterval(ticker);show("#loginView")};
$("#logoutAdmin").onclick=()=>{adminToken="";localStorage.removeItem("adminToken");show("#loginView")};

async function getLoc(){
 return new Promise((resolve,reject)=>{
  if(!navigator.geolocation) return reject(new Error("geo"));
  navigator.geolocation.getCurrentPosition(
   p=>resolve({lat:p.coords.latitude,lon:p.coords.longitude,accuracy:p.coords.accuracy}),
   reject,{enableHighAccuracy:true,timeout:12000,maximumAge:0}
  )
 });
}
async function doAction(type){
 let loc={};
 if(type==="CLOCK_IN"||type==="BREAK_END"){
  try{loc=await getLoc()}catch{return msg($("#empMsg"),tr("locationRequired"),"error")}
 }else{
  try{loc=await getLoc()}catch{}
 }
 try{
  const d=await api("/api/me/action",{method:"POST",body:JSON.stringify({type,...loc,deviceId})},empToken);
  currentStatus=d;renderEmployee(d);
 }catch(e){
  if(e.message==="outside_geofence") msg($("#empMsg"),`${tr("outside")} ${e.data?.distance?`(${e.data.distance}m)`:""}`,"error");
  else if(e.message==="device_mismatch") msg($("#empMsg"),tr("deviceMismatch"),"error");
  else msg($("#empMsg"),e.message,"error");
 }
}
async function refreshEmployee(){
 try{
  currentStatus=await api("/api/me/status",{},empToken);breakLimit=currentStatus.breakLimit||breakLimit;renderEmployee(currentStatus);
 }catch{$("#logoutEmp").click()}
}
function mmss(sec){
 sec=Math.max(0,Math.floor(sec));const m=Math.floor(sec/60),s=sec%60;
 return `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
}
function statusText(s){return s==="working"?tr("statusWorking"):s==="break"?tr("statusBreak"):tr("statusOff")}
function renderEmployee(st){
 $("#employeeName").textContent=(lang==="bn"&&employee?.name_bn)?employee.name_bn:employee?.name_ar||"";
 $("#serverTime").textContent=new Date().toLocaleString(lang==="bn"?"bn-BD":"ar-SA",{timeZone:"Asia/Riyadh"});
 const p=$("#statusPill");p.textContent=statusText(st.status);p.className="pill "+st.status;
 $("#breakBox").classList.toggle("hidden",st.status!=="break");
 const a=$("#empActions");a.innerHTML="";
 const btn=(txt,cls,type)=>{const b=document.createElement("button");b.textContent=txt;b.className=`${cls} bigAction`;b.onclick=()=>doAction(type);a.appendChild(b)};
 if(st.status==="off") btn(tr("clockIn"),"success","CLOCK_IN");
 if(st.status==="working"){btn(tr("breakStart"),"secondary","BREAK_START");btn(tr("clockOut"),"danger","CLOCK_OUT")}
 if(st.status==="break"){btn(tr("breakEnd"),"success","BREAK_END");btn(tr("clockOut"),"danger","CLOCK_OUT")}
 clearInterval(ticker);
 if(st.status==="break"&&st.breakStart){
  const update=()=>{
   const start=new Date(st.breakStart.server_time).getTime(), elapsedSec=(Date.now()-start)/1000;
   const limitSec=breakLimit*60, remaining=limitSec-elapsedSec, over=elapsedSec-limitSec;
   const timer=$("#breakTimer");
   if(remaining>=0){timer.textContent=mmss(remaining);timer.classList.remove("over");$("#breakMessage").textContent=`${tr("elapsed")} ${Math.floor(elapsedSec/60)} ${tr("minutes")} — ${tr("remaining")} ${Math.max(0,Math.ceil(remaining/60))} ${tr("minutes")}`}
   else{timer.textContent="+"+mmss(over);timer.classList.add("over");$("#breakMessage").textContent=`${tr("over")} ${Math.floor(over/60)} ${tr("minutes")}`}
   $("#breakProgress").style.width=Math.min(100,(elapsedSec/limitSec)*100)+"%";
  };update();ticker=setInterval(update,1000);
 }
}
function urlBase64ToUint8Array(base64String){
 const padding="=".repeat((4-base64String.length%4)%4),base64=(base64String+padding).replace(/-/g,"+").replace(/_/g,"/");
 const raw=atob(base64);return Uint8Array.from([...raw].map(c=>c.charCodeAt(0)));
}
$("#enableNotifications").onclick=async()=>{
 try{
  if(!("Notification" in window)||!("serviceWorker" in navigator)) throw new Error();
  const perm=await Notification.requestPermission();if(perm!=="granted") throw new Error();
  const cfg=await api("/api/config");vapidPublicKey=cfg.vapidPublicKey||vapidPublicKey;
  if(!vapidPublicKey){msg($("#empMsg"),tr("notificationsOn")+" (داخل التطبيق فقط)","ok");return}
  const reg=await navigator.serviceWorker.ready;
  let sub=await reg.pushManager.getSubscription();
  if(!sub) sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(vapidPublicKey)});
  await api("/api/me/push-subscription",{method:"POST",body:JSON.stringify({subscription:sub.toJSON()})},empToken);
  msg($("#empMsg"),tr("notificationsOn"),"ok");
 }catch{msg($("#empMsg"),tr("notificationDenied"),"error")}
};

let adminEmployees=[];
function renderAdminNames(){
 if(!adminToken)return;
 renderEmployees(adminEmployees);
}
async function refreshAdmin(){
 try{
  adminEmployees=await api("/api/admin/employees",{},adminToken);
  renderEmployees(adminEmployees);
  $("#workingCount").textContent=adminEmployees.filter(x=>x.status==="working").length;
  $("#breakCount").textContent=adminEmployees.filter(x=>x.status==="break").length;
  $("#offCount").textContent=adminEmployees.filter(x=>x.status==="off").length;
 }catch{$("#logoutAdmin").click()}
}
function renderEmployees(rows){
 const tb=$("#employeesBody");tb.innerHTML="";
 for(const e of rows){
  const trEl=document.createElement("tr");
  const nm=(lang==="bn"&&e.name_bn)?e.name_bn:e.name_ar;
  const mins=e.status==="break"?e.elapsedBreakMinutes:"—";
  trEl.innerHTML=`<td><b>${esc(nm)}</b><div class="small muted">#${esc(e.code)}</div></td>
  <td><span class="pill ${e.status}">${statusText(e.status)}</span></td>
  <td>${mins==="—"?"—":mins+" "+tr("minutes")}</td>
  <td><div class="actionsInline"><button class="secondary reset">${tr("resetDevice")}</button><button class="secondary toggle">${e.active?tr("disable"):tr("enable")}</button></div></td>`;
  trEl.querySelector(".reset").onclick=()=>adminAction(`/api/admin/employees/${e.id}/reset-device`);
  trEl.querySelector(".toggle").onclick=()=>adminAction(`/api/admin/employees/${e.id}/toggle`);
  tb.appendChild(trEl);
 }
}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
async function adminAction(url){await api(url,{method:"POST"},adminToken);await refreshAdmin()}
$("#refreshAdmin").onclick=refreshAdmin;
$("#addEmployeeBtn").onclick=async()=>{
 try{
  await api("/api/admin/employees",{method:"POST",body:JSON.stringify({
   name_ar:$("#newNameAr").value,name_bn:$("#newNameBn").value,code:$("#newCode").value,pin:$("#newPin").value
  })},adminToken);
  ["#newNameAr","#newNameBn","#newCode","#newPin"].forEach(x=>$(x).value="");
  msg($("#adminMsg"),tr("saved"),"ok");await refreshAdmin();
 }catch(e){msg($("#adminMsg"),e.message,"error")}
};
$("#reportMonth").value=new Date().toISOString().slice(0,7);
$("#loadReport").onclick=async()=>{
 const rows=await api("/api/admin/report?month="+encodeURIComponent($("#reportMonth").value),{},adminToken);
 $("#reportTable").innerHTML=`<table><thead><tr><th>${tr("name")}</th><th>${tr("attendanceDays")}</th><th>${tr("workMinutes")}</th><th>${tr("breakMinutes")}</th><th>${tr("breakOver")}</th></tr></thead><tbody>${
  rows.map(r=>`<tr><td>${esc((lang==="bn"&&r.name_bn)?r.name_bn:r.name_ar)}</td><td>${r.attendance_days}</td><td>${r.work_minutes}</td><td>${r.break_minutes}</td><td>${r.break_over_minutes}</td></tr>`).join("")
 }</tbody></table>`;
};
$("#downloadCsv").onclick=async()=>{
 const r=await fetch("/api/admin/report.csv?month="+encodeURIComponent($("#reportMonth").value),{headers:{Authorization:"Bearer "+adminToken}});
 if(!r.ok)return;const b=await r.blob(),u=URL.createObjectURL(b),a=document.createElement("a");a.href=u;a.download=`qamra-${$("#reportMonth").value}.csv`;a.click();URL.revokeObjectURL(u);
};

(async()=>{
 try{const cfg=await api("/api/config");breakLimit=cfg.breakLimit||40;vapidPublicKey=cfg.vapidPublicKey||""}catch{}
 if(empToken&&employee){show("#employeeView");await refreshEmployee()}
 else if(adminToken){show("#adminView");await refreshAdmin()}
 else show("#loginView");
 setInterval(()=>{if(adminToken&&!$("#adminView").classList.contains("hidden"))refreshAdmin()},30000);
})();
